
"use strict";

let sensorData = require('./sensorData.js');

module.exports = {
  sensorData: sensorData,
};
