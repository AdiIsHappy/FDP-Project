// Auto-generated. Do not edit!

// (in-package SensorData.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class sensorData {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.frontUS = null;
      this.backUS = null;
      this.leftIR = null;
      this.rightIR = null;
    }
    else {
      if (initObj.hasOwnProperty('frontUS')) {
        this.frontUS = initObj.frontUS
      }
      else {
        this.frontUS = 0.0;
      }
      if (initObj.hasOwnProperty('backUS')) {
        this.backUS = initObj.backUS
      }
      else {
        this.backUS = 0.0;
      }
      if (initObj.hasOwnProperty('leftIR')) {
        this.leftIR = initObj.leftIR
      }
      else {
        this.leftIR = 0.0;
      }
      if (initObj.hasOwnProperty('rightIR')) {
        this.rightIR = initObj.rightIR
      }
      else {
        this.rightIR = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type sensorData
    // Serialize message field [frontUS]
    bufferOffset = _serializer.float64(obj.frontUS, buffer, bufferOffset);
    // Serialize message field [backUS]
    bufferOffset = _serializer.float64(obj.backUS, buffer, bufferOffset);
    // Serialize message field [leftIR]
    bufferOffset = _serializer.float64(obj.leftIR, buffer, bufferOffset);
    // Serialize message field [rightIR]
    bufferOffset = _serializer.float64(obj.rightIR, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type sensorData
    let len;
    let data = new sensorData(null);
    // Deserialize message field [frontUS]
    data.frontUS = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [backUS]
    data.backUS = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [leftIR]
    data.leftIR = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [rightIR]
    data.rightIR = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 32;
  }

  static datatype() {
    // Returns string type for a message object
    return 'SensorData/sensorData';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '21de1e2285327d012ad129c88d0d2c86';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float64 frontUS
    float64 backUS
    float64 leftIR
    float64 rightIR
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new sensorData(null);
    if (msg.frontUS !== undefined) {
      resolved.frontUS = msg.frontUS;
    }
    else {
      resolved.frontUS = 0.0
    }

    if (msg.backUS !== undefined) {
      resolved.backUS = msg.backUS;
    }
    else {
      resolved.backUS = 0.0
    }

    if (msg.leftIR !== undefined) {
      resolved.leftIR = msg.leftIR;
    }
    else {
      resolved.leftIR = 0.0
    }

    if (msg.rightIR !== undefined) {
      resolved.rightIR = msg.rightIR;
    }
    else {
      resolved.rightIR = 0.0
    }

    return resolved;
    }
};

module.exports = sensorData;
